# CLOUD PLAY PS2 — v0.1.0-demo

App Android (Kotlin + Jetpack Compose) + servidor Node.js de demonstração.
**Streaming e emulação ainda NÃO existem nesta versão.** Veja `docs/ARQUITETURA.md`.

## Rodar o servidor (PC)
```bash
cd server && node server.js          # Node 18+
curl http://localhost:8080/api/health
curl http://localhost:8080/api/games
```

## Rodar o app no celular Android
1. Instale o **Android Studio** e abra a pasta do projeto (ele gera o Gradle Wrapper e baixa o SDK 34).
2. No celular: Configurações > Sobre > toque 7x em "Número da versão"; ative **Depuração USB**.
3. Conecte por USB, aceite a autorização, escolha o aparelho no Android Studio e clique **Run ▶**.
4. Use o app sem servidor: entre com um nome, navegue, abra um jogo, toque **JOGAR**, use o controle virtual e **Salvar**.
5. Com servidor: PC e celular na mesma Wi-Fi; descubra o IP do PC (ex.: `192.168.0.10`), rode o servidor, e em **Servidor** digite `http://192.168.0.10:8080` > **Testar** > **Sincronizar catálogo** (deve aparecer "Extra do Servidor"). (No emulador do Android Studio o padrão `10.0.2.2:8080` já funciona.)
6. Bluetooth: pareie um controle nas configurações do Android, abra um jogo e aperte botões; o texto "Último botão" deve mudar.

## Checklist de teste manual
- [ ] Login e persistência após fechar o app
- [ ] Busca e filtro por categoria
- [ ] Controle virtual atualiza "Último botão"
- [ ] Salvar progresso aparece em Detalhes e Perfil
- [ ] Servidor: teste, sync e `server/db.json` recebe o progresso
- [ ] Controle Bluetooth

## Limitações conhecidas
Capas são geradas por gradiente (sem imagens). Catálogo é de entradas de demonstração, sem arquivos de jogo. HTTP em texto puro habilitado apenas para testes.
