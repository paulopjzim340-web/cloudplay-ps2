# Gerar e instalar o APK só com o celular
Veja o passo a passo completo na conversa/README. Resumo:
1. Crie conta e um repositório no GitHub (app ou navegador).
2. Crie o arquivo `.github/workflows/build.yml` (conteúdo em `.github/workflows/build.yml` deste projeto).
3. Envie `cloudplay-ps2.zip` para a raiz do repositório (Add file > Upload files).
4. Aba Actions > "Build APK" > aguarde o ✔ verde (~5-10 min na primeira vez).
5. Aba Releases > baixe `CloudPlayPS2.apk` e instale.
Erro de build? Abra o job vermelho e copie as últimas linhas do log.
