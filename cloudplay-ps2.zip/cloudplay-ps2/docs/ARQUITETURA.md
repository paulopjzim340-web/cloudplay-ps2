# Arquitetura

```
[Android app] --HTTP/JSON--> [server/server.js]  (catálogo, progresso)
      |                              |
 InputBus (touch + Bluetooth)        +--(FUTURO) Host de emulação: PCSX2 + captura A/V + WebRTC
      |                                          ^ entrada do controle via DataChannel
 StreamClient (FUTURO) <---- vídeo/áudio WebRTC -+
```

## Estado atual (v0.1.0-demo)
| Recurso | Estado |
|---|---|
| Navegação, login local, biblioteca, busca, categorias, detalhes, perfil | Implementado (código; ver README sobre testes) |
| Controle virtual de PS2 (digital) | Implementado; sticks analógicos: pendente |
| Controle Bluetooth/USB | Mapeamento básico de botões via KeyEvent; sticks/gatilhos analógicos pendentes |
| Salvamento de progresso | Local (SharedPreferences) + envio best-effort ao servidor |
| Servidor | Catálogo + progresso em JSON. Login real/autenticação: pendente |
| **Streaming de vídeo/áudio** | **NÃO implementado.** Tela do player tem área reservada |
| Emulação PS2 | **NÃO implementada** |

## Próximos passos para streaming real
1. Host (PC/VPS com GPU) executando PCSX2 (GPL) com BIOS e jogos **dumpados por você** dos seus próprios discos.
2. Capturar vídeo/áudio (ex.: FFmpeg/GStreamer) e publicar via WebRTC.
3. No Android, adicionar `StreamClient` (lib WebRTC) renderizando em `SurfaceViewRenderer`.
4. Enviar `InputBus.events` ao host por DataChannel; host injeta no emulador (ex.: uinput/vJoy).
5. Autenticação (JWT), HTTPS, saves de memory card no servidor.

## Legal
O app e o repositório não contêm jogos comerciais nem BIOS. Usuário fornece seus próprios arquivos legítimos.
Verifique a licença de qualquer homebrew antes de adicioná-lo ao catálogo.
