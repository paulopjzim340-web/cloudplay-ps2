// Servidor de demonstração (Node 18+, sem dependências). Catálogo + login simples + progresso.
// NÃO faz streaming ainda: /api/stream/session responde 501 de propósito.
const http = require('http'), fs = require('fs'), path = require('path');
const PORT = process.env.PORT || 8080;
const DB = path.join(__dirname, 'db.json');
const catalog = JSON.parse(fs.readFileSync(path.join(__dirname, 'catalog.json'), 'utf8'));
const load = () => { try { return JSON.parse(fs.readFileSync(DB, 'utf8')); } catch { return { progress: {} }; } };
const save = d => fs.writeFileSync(DB, JSON.stringify(d, null, 2));
const send = (res, code, obj) => { res.writeHead(code, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(obj)); };

http.createServer((req, res) => {
  const parts = req.url.split('?')[0].split('/').filter(Boolean);
  if (parts[0] !== 'api') return send(res, 404, { error: 'not found' });
  if (req.method === 'GET' && parts[1] === 'health') return send(res, 200, { name: 'CloudPlay PS2 demo server', streaming: false });
  if (req.method === 'GET' && parts[1] === 'games') return send(res, 200, catalog);
  if (parts[1] === 'progress' && parts.length === 4) {
    const [, , user, game] = parts;
    const db = load();
    if (req.method === 'GET') return send(res, 200, (db.progress[user] || {})[game] || {});
    if (req.method === 'PUT') {
      let body = '';
      req.on('data', c => body += c);
      return req.on('end', () => {
        try { (db.progress[user] ||= {})[game] = JSON.parse(body); save(db); send(res, 200, { ok: true }); }
        catch { send(res, 400, { error: 'invalid json' }); }
      });
    }
  }
  if (parts[1] === 'stream') return send(res, 501, { error: 'streaming not implemented' });
  send(res, 404, { error: 'not found' });
}).listen(PORT, '0.0.0.0', () => console.log('CloudPlay server on :' + PORT));
