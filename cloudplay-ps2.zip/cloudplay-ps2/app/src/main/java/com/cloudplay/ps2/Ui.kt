package com.cloudplay.ps2

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import kotlinx.coroutines.delay

val Accent = Color(0xFF3D7BFF)
val Bg = Color(0xFF0B0D14)
val Card = Color(0xFF151927)

@Composable fun CloudTheme(content: @Composable () -> Unit) =
    MaterialTheme(colorScheme = darkColorScheme(primary = Accent, background = Bg, surface = Card, onBackground = Color.White, onSurface = Color.White)) {
        Surface(Modifier.fillMaxSize(), color = Bg) { content() }
    }

@Composable fun App(vm: AppVm) {
    val nav = rememberNavController()
    NavHost(nav, if (vm.user == null) "login" else "home") {
        composable("login") {
            LoginScreen { vm.login(it); nav.navigate("home") { popUpTo("login") { inclusive = true } } }
        }
        composable("home") {
            HomeScreen(vm, { nav.navigate("detail/$it") }, { nav.navigate("connect") }, { nav.navigate("profile") })
        }
        composable("detail/{id}") { e ->
            vm.game(e.arguments?.getString("id"))?.let { g ->
                DetailScreen(g, vm, { nav.navigate("player/${g.id}") }, { nav.popBackStack() })
            }
        }
        composable("player/{id}") { e ->
            vm.game(e.arguments?.getString("id"))?.let { g -> PlayerScreen(g, vm) { nav.popBackStack() } }
        }
        composable("connect") { ConnectScreen(vm) { nav.popBackStack() } }
        composable("profile") {
            ProfileScreen(vm, { nav.popBackStack() }) {
                vm.logout(); nav.navigate("login") { popUpTo("home") { inclusive = true } }
            }
        }
    }
}

@Composable fun Cover(g: Game, modifier: Modifier) {
    val h = (g.id.hashCode() and 0x7FFFFFFF) % 360
    val c1 = Color(android.graphics.Color.HSVToColor(floatArrayOf(h.toFloat(), 0.7f, 0.55f)))
    val c2 = Color(android.graphics.Color.HSVToColor(floatArrayOf(((h + 50) % 360).toFloat(), 0.8f, 0.25f)))
    Box(modifier.background(Brush.linearGradient(listOf(c1, c2))), contentAlignment = Alignment.Center) {
        Text(g.title.take(2).uppercase(), fontSize = 40.sp, fontWeight = FontWeight.Black, color = Color.White.copy(alpha = .85f))
    }
}

@Composable fun LoginScreen(onLogin: (String) -> Unit) {
    var name by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(32.dp), Arrangement.Center, Alignment.CenterHorizontally) {
        Text("CLOUD PLAY", fontSize = 34.sp, fontWeight = FontWeight.Black, color = Accent)
        Text("PS2 • demo", color = Color.Gray)
        Spacer(Modifier.height(32.dp))
        OutlinedTextField(name, { name = it }, label = { Text("Nome do jogador") }, singleLine = true)
        Spacer(Modifier.height(16.dp))
        Button({ onLogin(name) }, enabled = name.isNotBlank()) { Text("ENTRAR") }
    }
}

@Composable fun HomeScreen(vm: AppVm, onGame: (String) -> Unit, onConnect: () -> Unit, onProfile: () -> Unit) {
    var q by remember { mutableStateOf("") }
    var cat by remember { mutableStateOf<String?>(null) }
    val cats = vm.games.map { it.genre }.distinct()
    val list = vm.games.filter { (cat == null || it.genre == cat) && it.title.contains(q, true) }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
            Text("BIBLIOTECA", fontSize = 22.sp, fontWeight = FontWeight.Black)
            Row { TextButton(onConnect) { Text("Servidor") }; TextButton(onProfile) { Text("Perfil") } }
        }
        OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth(), placeholder = { Text("Pesquisar jogos") }, singleLine = true)
        LazyRow(Modifier.padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            item { FilterChip(cat == null, { cat = null }, { Text("Todos") }) }
            items(cats) { c -> FilterChip(cat == c, { cat = if (cat == c) null else c }, { Text(c) }) }
        }
        LazyVerticalGrid(GridCells.Adaptive(140.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(list) { g ->
                Column(Modifier.clip(RoundedCornerShape(14.dp)).background(Card).clickable { onGame(g.id) }) {
                    Cover(g, Modifier.fillMaxWidth().height(150.dp))
                    Text(g.title, Modifier.padding(10.dp), fontWeight = FontWeight.SemiBold, maxLines = 2)
                }
            }
        }
    }
}

@Composable fun DetailScreen(g: Game, vm: AppVm, onPlay: () -> Unit, onBack: () -> Unit) {
    val p = vm.progress(g.id)
    Column(Modifier.fillMaxSize()) {
        Box { Cover(g, Modifier.fillMaxWidth().height(260.dp)); TextButton(onBack) { Text("← Voltar") } }
        Column(Modifier.padding(20.dp)) {
            Text(g.title, fontSize = 26.sp, fontWeight = FontWeight.Black)
            Text("${g.genre} • ${g.year} • Licença: ${g.license}", color = Color.Gray)
            Spacer(Modifier.height(12.dp)); Text(g.description)
            Spacer(Modifier.height(12.dp))
            Text("Tempo jogado: ${p.seconds / 60} min", color = Color.Gray)
            if (p.note.isNotBlank()) Text("Último save: ${p.note}", color = Color.Gray)
            Spacer(Modifier.height(20.dp))
            Button(onPlay, Modifier.fillMaxWidth().height(52.dp)) { Text("JOGAR", fontWeight = FontWeight.Black) }
        }
    }
}

@Composable fun PadButton(label: String, btn: Btn, w: Int = 48, h: Int = 48) {
    var down by remember { mutableStateOf(false) }
    Box(
        Modifier.size(w.dp, h.dp).clip(if (w == h) CircleShape else RoundedCornerShape(10.dp))
            .background(if (down) Accent else Color(0xFF232838))
            .pointerInput(btn) {
                detectTapGestures(onPress = {
                    down = true; InputBus.emit(PadEvent(btn, true))
                    tryAwaitRelease()
                    down = false; InputBus.emit(PadEvent(btn, false))
                })
            },
        contentAlignment = Alignment.Center
    ) { Text(label, fontSize = 13.sp, fontWeight = FontWeight.Bold) }
}

@Composable fun VirtualPad() {
    Row(Modifier.fillMaxWidth().padding(12.dp), Arrangement.SpaceBetween, Alignment.Bottom) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { PadButton("L2", Btn.L2, 60, 34); PadButton("L1", Btn.L1, 60, 34) }
            Spacer(Modifier.height(10.dp))
            PadButton("▲", Btn.UP)
            Row { PadButton("◀", Btn.LEFT); Spacer(Modifier.width(36.dp)); PadButton("▶", Btn.RIGHT) }
            PadButton("▼", Btn.DOWN)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { PadButton("SELECT", Btn.SELECT, 64, 30); PadButton("START", Btn.START, 64, 30) }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { PadButton("R1", Btn.R1, 60, 34); PadButton("R2", Btn.R2, 60, 34) }
            Spacer(Modifier.height(10.dp))
            PadButton("△", Btn.TRIANGLE)
            Row { PadButton("□", Btn.SQUARE); Spacer(Modifier.width(36.dp)); PadButton("○", Btn.CIRCLE) }
            PadButton("✕", Btn.CROSS)
        }
    }
}

@Composable fun PlayerScreen(g: Game, vm: AppVm, onExit: () -> Unit) {
    val base = remember { vm.progress(g.id) }
    var session by remember { mutableStateOf(0L) }
    var last by remember { mutableStateOf("—") }
    var note by remember { mutableStateOf(base.note) }
    val save = { vm.saveProgress(g.id, Progress(base.seconds + session, System.currentTimeMillis(), note)) }
    LaunchedEffect(Unit) { while (true) { delay(1000); session++ } }
    LaunchedEffect(Unit) { InputBus.events.collect { last = "${it.btn} ${if (it.pressed) "↓" else "↑"}" } }
    DisposableEffect(Unit) { onDispose { save() } }
    Column(Modifier.fillMaxSize()) {
        Box(Modifier.fillMaxWidth().weight(1f).background(Color.Black), Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(24.dp)) {
                Text(g.title, fontWeight = FontWeight.Black, fontSize = 20.sp)
                Spacer(Modifier.height(8.dp))
                Text("SEM STREAMING — modo demo local.\nÁrea reservada para vídeo/áudio do servidor.", color = Color.Gray)
                Spacer(Modifier.height(12.dp))
                Text("Sessão: ${session}s  •  Último botão: $last", color = Accent)
            }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), Arrangement.spacedBy(8.dp), Alignment.CenterVertically) {
            OutlinedTextField(note, { note = it }, Modifier.weight(1f), label = { Text("Nota do save") }, singleLine = true)
            Button({ save() }) { Text("Salvar") }
            TextButton(onExit) { Text("Sair") }
        }
        VirtualPad()
    }
}

@Composable fun ConnectScreen(vm: AppVm, onBack: () -> Unit) {
    var url by remember { mutableStateOf(vm.serverUrl) }
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        TextButton(onBack) { Text("← Voltar") }
        Text("CONEXÃO COM SERVIDOR", fontSize = 20.sp, fontWeight = FontWeight.Black)
        OutlinedTextField(url, { url = it }, Modifier.fillMaxWidth(), label = { Text("URL (ex: http://192.168.0.10:8080)") }, singleLine = true)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button({ vm.testServer(url) }) { Text("Testar") }
            OutlinedButton({ vm.syncCatalog() }) { Text("Sincronizar catálogo") }
        }
        Text("Status: ${vm.status}")
        Text("Streaming de vídeo/áudio: NÃO IMPLEMENTADO nesta versão.", color = Color(0xFFFFB74D))
    }
}

@Composable fun ProfileScreen(vm: AppVm, onBack: () -> Unit, onLogout: () -> Unit) {
    vm.version // recompõe após saves
    val all = vm.allProgress()
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        TextButton(onBack) { Text("← Voltar") }
        Text(vm.user ?: "", fontSize = 26.sp, fontWeight = FontWeight.Black)
        Text("Tempo total: ${all.values.sumOf { it.seconds } / 60} min • Jogos jogados: ${all.size}", color = Color.Gray)
        all.forEach { (id, p) -> Text("• ${vm.game(id)?.title ?: id}: ${p.seconds / 60} min ${p.note}") }
        Spacer(Modifier.height(16.dp))
        OutlinedButton(onLogout) { Text("Sair da conta") }
    }
}
