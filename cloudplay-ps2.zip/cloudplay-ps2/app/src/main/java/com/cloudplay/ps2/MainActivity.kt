package com.cloudplay.ps2

import android.os.Bundle
import android.view.KeyEvent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels

class MainActivity : ComponentActivity() {
    private val vm: AppVm by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CloudTheme { App(vm) } }
    }

    // Controles Bluetooth/USB pareados no Android chegam aqui como KeyEvents.
    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        val b = keyToBtn(e.keyCode)
        if (b != null && e.repeatCount == 0) {
            InputBus.emit(PadEvent(b, e.action == KeyEvent.ACTION_DOWN))
            return true
        }
        return super.dispatchKeyEvent(e)
    }
}
