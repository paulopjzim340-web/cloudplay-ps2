package com.cloudplay.ps2

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch

class AppVm(app: Application) : AndroidViewModel(app) {
    private val store = Store(app)
    var user by mutableStateOf(store.user)
        private set
    var serverUrl by mutableStateOf(store.serverUrl)
        private set
    var status by mutableStateOf("Não testado")
        private set
    var games by mutableStateOf(DemoCatalog.games)
        private set
    var version by mutableStateOf(0)
        private set   // força recomposição após salvar progresso

    fun login(name: String) { store.user = name.trim(); user = name.trim() }
    fun logout() { store.user = null; user = null }
    fun game(id: String?) = games.find { it.id == id }
    fun progress(id: String) = store.progress(id)
    fun allProgress() = store.allProgress()

    fun saveProgress(id: String, p: Progress) {
        store.save(id, p); version++
        val u = user ?: return
        viewModelScope.launch { ServerApi.push(serverUrl, u, id, p) } // best-effort; ignora falha
    }

    fun testServer(url: String) {
        serverUrl = url.trim().trimEnd('/'); store.serverUrl = serverUrl
        status = "Testando…"
        viewModelScope.launch {
            status = ServerApi.health(serverUrl).fold({ "Conectado: $it" }, { "Falha: ${it.message}" })
        }
    }

    fun syncCatalog() = viewModelScope.launch {
        ServerApi.games(serverUrl).onSuccess { games = it; status = "Catálogo sincronizado (${it.size} jogos)" }
            .onFailure { status = "Falha ao sincronizar: ${it.message}" }
    }
}
