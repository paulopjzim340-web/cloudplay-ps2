package com.cloudplay.ps2

data class Game(
    val id: String, val title: String, val genre: String,
    val year: Int, val description: String, val license: String
)

data class Progress(val seconds: Long = 0, val lastPlayed: Long = 0, val note: String = "")

/** Catálogo local de demonstração. SÃO ENTRADAS DE TESTE (sem arquivos de jogo).
 *  Substitua por homebrew/test ROMs cuja licença você tenha verificado. */
object DemoCatalog {
    val games = listOf(
        Game("pad-test", "Pad Test (homebrew)", "Utilitário", 2024, "Teste de botões do controle. Entrada de demonstração.", "Demo"),
        Game("snake-hb", "Snake Homebrew", "Arcade", 2023, "Exemplo de homebrew. Entrada de demonstração.", "Demo"),
        Game("tetris-hb", "Blocks Homebrew", "Puzzle", 2022, "Exemplo de puzzle homebrew. Entrada de demonstração.", "Demo"),
        Game("racer-hb", "Racer Homebrew", "Corrida", 2021, "Exemplo de corrida homebrew. Entrada de demonstração.", "Demo"),
        Game("quest-hb", "Quest Homebrew", "Aventura", 2020, "Exemplo de aventura homebrew. Entrada de demonstração.", "Demo")
    )
}
