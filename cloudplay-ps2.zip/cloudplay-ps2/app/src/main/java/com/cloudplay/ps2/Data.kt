package com.cloudplay.ps2

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Persistência local (SharedPreferences): usuário, servidor e progresso por jogo. */
class Store(ctx: Context) {
    private val sp = ctx.getSharedPreferences("cloudplay", Context.MODE_PRIVATE)
    var user: String?
        get() = sp.getString("user", null)
        set(v) { sp.edit().putString("user", v).apply() }
    var serverUrl: String
        get() = sp.getString("server", "http://10.0.2.2:8080")!!
        set(v) { sp.edit().putString("server", v).apply() }

    fun progress(id: String): Progress {
        val s = sp.getString("p_$id", null) ?: return Progress()
        return runCatching {
            val o = JSONObject(s); Progress(o.getLong("s"), o.getLong("l"), o.optString("n"))
        }.getOrDefault(Progress())
    }
    fun save(id: String, p: Progress) {
        val o = JSONObject().put("s", p.seconds).put("l", p.lastPlayed).put("n", p.note)
        sp.edit().putString("p_$id", o.toString()).apply()
    }
    fun allProgress(): Map<String, Progress> =
        sp.all.keys.filter { it.startsWith("p_") }.associate { it.removePrefix("p_") to progress(it.removePrefix("p_")) }
}

/** Cliente da API do servidor (ver /server). Falhas retornam Result.failure — o app funciona offline. */
object ServerApi {
    private fun open(url: String, method: String = "GET") =
        (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = method; connectTimeout = 4000; readTimeout = 4000
        }

    private suspend fun get(url: String): String = withContext(Dispatchers.IO) {
        val c = open(url)
        try { c.inputStream.bufferedReader().readText() } finally { c.disconnect() }
    }

    suspend fun health(base: String) = runCatching { JSONObject(get("$base/api/health")).getString("name") }

    suspend fun games(base: String) = runCatching {
        val a = JSONArray(get("$base/api/games"))
        (0 until a.length()).map {
            val o = a.getJSONObject(it)
            Game(o.getString("id"), o.getString("title"), o.getString("genre"),
                o.getInt("year"), o.getString("description"), o.getString("license"))
        }
    }

    suspend fun push(base: String, user: String, id: String, p: Progress) = runCatching {
        withContext(Dispatchers.IO) {
            val c = open("$base/api/progress/$user/$id", "PUT")
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            val body = JSONObject().put("seconds", p.seconds).put("lastPlayed", p.lastPlayed).put("note", p.note)
            c.outputStream.use { it.write(body.toString().toByteArray()) }
            c.responseCode; c.disconnect()
        }
    }
}
