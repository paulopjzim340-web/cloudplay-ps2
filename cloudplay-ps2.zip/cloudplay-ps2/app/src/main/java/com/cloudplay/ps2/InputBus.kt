package com.cloudplay.ps2

import android.view.KeyEvent
import kotlinx.coroutines.flow.MutableSharedFlow

enum class Btn { UP, DOWN, LEFT, RIGHT, CROSS, CIRCLE, SQUARE, TRIANGLE, L1, L2, R1, R2, L3, R3, START, SELECT }
data class PadEvent(val btn: Btn, val pressed: Boolean)

/** Barramento único: controle virtual E Bluetooth publicam aqui. No futuro, um StreamClient envia ao servidor. */
object InputBus {
    val events = MutableSharedFlow<PadEvent>(extraBufferCapacity = 64)
    fun emit(e: PadEvent) = events.tryEmit(e)
}

fun keyToBtn(code: Int): Btn? = when (code) {
    KeyEvent.KEYCODE_BUTTON_A -> Btn.CROSS
    KeyEvent.KEYCODE_BUTTON_B -> Btn.CIRCLE
    KeyEvent.KEYCODE_BUTTON_X -> Btn.SQUARE
    KeyEvent.KEYCODE_BUTTON_Y -> Btn.TRIANGLE
    KeyEvent.KEYCODE_BUTTON_L1 -> Btn.L1
    KeyEvent.KEYCODE_BUTTON_R1 -> Btn.R1
    KeyEvent.KEYCODE_BUTTON_L2 -> Btn.L2
    KeyEvent.KEYCODE_BUTTON_R2 -> Btn.R2
    KeyEvent.KEYCODE_BUTTON_THUMBL -> Btn.L3
    KeyEvent.KEYCODE_BUTTON_THUMBR -> Btn.R3
    KeyEvent.KEYCODE_BUTTON_START -> Btn.START
    KeyEvent.KEYCODE_BUTTON_SELECT -> Btn.SELECT
    KeyEvent.KEYCODE_DPAD_UP -> Btn.UP
    KeyEvent.KEYCODE_DPAD_DOWN -> Btn.DOWN
    KeyEvent.KEYCODE_DPAD_LEFT -> Btn.LEFT
    KeyEvent.KEYCODE_DPAD_RIGHT -> Btn.RIGHT
    else -> null
}
